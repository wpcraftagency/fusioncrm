#  Nevezd meg! - Ne add el! - Így add tovább! 4.0 Nemzetközi (CC BY-NC-SA 4.0) 

:::warning Figyelem
Ez egy ember által olvasható összefoglalója a licencnek (és nem helyettesíti azt). A teljes szöveg a [Creative Commons honlapján](https://creativecommons.org/licenses/by-nc-sa/4.0/legalcode) található.
:::

## A Hub tartalmát szabadon

* **Megoszthatod** — másolhatod és terjesztheted a tartalmat bármilyen módon vagy formában
* **Átdolgozhatod** — származékos műveket hozhatsz létre, átalakíthatod és új művekbe építheted be

A jogosult (mi) nem vonhatja vissza ezen engedélyeket míg betartod a licenc feltételeit.

## Az alábbi feltételekkel:

1. **Nevezd meg!** — A szerzőt megfelelően fel kell tüntetned, hivatkozást kell létrehoznod a licencre és jelezned ha a művön változtatást hajtottál végre. Ezt bármilyen ésszerű módon megteheted, kivéve oly módon ami azt sugallná hogy a jogosult támogat téged vagy a felhasználásod körülményeit.

2. **Ne add el!** — Nem használhatod a művet üzleti célokra.

3. **Így add tovább!** — Ha feldolgozod, átalakítod vagy gyűjteményes művet hozol létre a műből akkor a létrejött művet ugyanazon licencfeltételek mellett kell terjesztened mint az eredetit.

4. **Nincsenek további megkötések** — Nem szabhatsz meg más jogi vagy technológiai korlátozásokat melyek megakadályoznának bárkit abban hogy ezen licenc által engedélyezett bármely tevékenységeket folytassák.

Forrás: https://creativecommons.org/licenses/by-nc-sa/4.0/deed.hu