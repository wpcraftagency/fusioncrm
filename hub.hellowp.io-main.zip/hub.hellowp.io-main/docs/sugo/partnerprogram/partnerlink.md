---
sidebar_position: 3
---

# Partnerlink

A partnerlink segítségével követheted a hivatkozásaidat és a jutalékodat. A partnerlinket a HelloConsole-ban találod meg.

## Hol találod a partnerlinket?

1. Lépj be a HelloWP oldalon: https://hellowp.io/hu/helloconsole/
2. Kattints baloldalt fent a nevedre, majd a HelloConsole-ra
3. Kattints a **Bevételeid** menüpontra
4. Kattints a **Partnerprogram központ** gombra
5. Kattints a **Partnerazonosítód** gombra
6. Itt találod a partnerlinket

**Partnerlink így néz ki:** `https://hellowp.io/hu/partner/ID-SZÁMOD/`

**Egyedi linkek:** A HelloWP! bármelyik oldalából készíthetsz egyedi linkeket, csak a `/partner/ID-SZÁMOD/` részt kell az URL mögé írni. 

Például: `https://hellowp.io/hu/t/webshop-es-weboldal-tarhely-es-karbantartas/partner/ID-SZÁMOD/`