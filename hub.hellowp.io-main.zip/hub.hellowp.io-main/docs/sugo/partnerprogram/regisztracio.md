---
sidebar_position: 2
---

# Regisztráció

A HelloWP! partnerprogramba való regisztráció ingyenes. A regisztrációt a Partnerprogram oldalon található **Csatlakozz a partnerprogramhoz!** űrlapon keresztül teheted meg. 