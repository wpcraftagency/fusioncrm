---
sidebar_position: 6
---

# Számla

A számla feltöltése után a HelloWP! csapata ellenőrzi a számlát, majd a jutalék kifizetésére kerül sor.

## Számla feltöltése

1. Lépj be a HelloWP oldalon: https://hellowp.io/hu/helloconsole/
2. Kattints baloldalt fent a nevedre, majd a HelloConsole-ra
3. Kattints a **Bevételeid** menüpontra
4. Kattints a **Kifizethető bevételeid kivétele** gombra
5. Töltsd fel a számlát (a **Kifizethető bevételeid kivétele** oldalon látható összeggel) a felugró ablakon keresztül. A számla utalásos fizetési módon keresztül kerül kifizetésre.

## Számlázási adatok

**Cégnév:** TooEarlyBird, LLC

**Székhely:**

**Cím:** 30 N Gould St Ste N 
**Város:** Sheridan, 
**Állam:** WY 
**Irányítószám:** 82801
**Ország:** USA