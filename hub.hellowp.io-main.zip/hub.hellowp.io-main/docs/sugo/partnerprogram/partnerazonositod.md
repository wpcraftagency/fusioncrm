---
sidebar_position: 3
---

# Partnerazonosítód

A partnerazonosító az a szám, amivel a HelloWP! partnerprogramban való részvételhez és a jutalék kifizetéséhez szükséges. 

## Hol találod a partnerazonosítód?

1. Lépj be a HelloWP oldalon: https://hellowp.io/hu/helloconsole/
2. Kattints baloldalt fent a nevedre, majd a HelloConsole-ra
3. Kattints a **Bevételeid** menüpontra
4. Kattints a **Partnerprogram központ** gombra
5. Kattints a **Partnerazonosítód** gombra

