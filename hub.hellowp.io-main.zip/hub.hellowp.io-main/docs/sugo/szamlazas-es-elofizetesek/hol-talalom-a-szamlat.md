---
sidebar_position: 2
---

# Hol találom a számlát?

A HelloWP! minden rendelés után számlát állít ki, amit könnyedén (és bármikor) elérsz a Console oldalon keresztül.

**Így férhetsz hozzá a számlákhoz: **

1. Lépj be a HelloWP oldalon: https://hellowp.io/hu/helloconsole/
2. Kattints baloldalt fent a Pénzügyek menüpontra: https://hellowp.io/hu/helloconsole/orders/ Itt találod az összes rendelésedet
3. **A számla letöltéshez kattints az adott rendelés mellett látható SZÁMLA feliratra**