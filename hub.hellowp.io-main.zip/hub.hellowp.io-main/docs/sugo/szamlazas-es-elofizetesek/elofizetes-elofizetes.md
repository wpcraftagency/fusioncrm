---
sidebar_position: 4
---

# Előfizetés elindítása

A HelloWP.io oldalon az összes előfizetési formában kapható termék ára mellett feltüntetett /hónap vagy /év felirat jelzi, hogy nem egyszeri összegről, hanem ismétlődő fizetésről van szó. 

Az előfizetés elindításához először válassz egy terméket, majd kattints a **Megrendelem** gombra.

Ne felejtsd el, hogy az előfizetéseket bármikor lemondhatod.  [Előfizetés lemondása](./elofizetes-lemondasa)