---
sidebar_position: 5
---

# Előfizetés újraaktiválása

Lejárt az előfizetésed, vagy bármilyen ok miatt nem tudta megújítani a rendszer? Semmi probléma, könnyedén folytathatod az előfizetést. 

1. Lépj be a **HelloWP Console**-ba: https://hellowp.io/hu/helloconsole/
2. Kattints a **Előfizetések** menüpontra: https://hellowp.io/hu/helloconsole/subscriptions/
3. Válaszd ki a megfelelő előfizetést és kattints a **Fizetés** gombra
4. Vidd végig a folyamatot, és kész is vagy!