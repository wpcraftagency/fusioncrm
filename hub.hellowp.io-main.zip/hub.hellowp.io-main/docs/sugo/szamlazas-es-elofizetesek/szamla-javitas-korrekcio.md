---
sidebar_position: 3
---

# Számla javítás/korrekció


Győződj meg róla, hogy a megadott számlázási adatok helyesek-e: https://hellowp.io/hu/helloconsole/edit-address/szamlazas/

Amennyiben minden rendben van és az adatok helyesek, vedd fel a kapcsolatot a pénzügyi részleggel. A pénzügyi részleg elérhetősége: https://hellowp.io/hu/tamogatas Itt a **Témaköröknél** válaszd ki a **Számlázás és előfizetések** témakört. Akkor sincs gond, ha véletlenül elrontod és más témakört adtál meg, azonban ilyenkor a feldolgozás több időt vehet igénybe. Erre csak akkor van lehetőséged, ha már leadtad a rendelést és TELJESÍTETT státuszban van. Minden más esetben a [Számlázási adatok módosítása](szamlazasi-adat-modositas#számlázási-adatok-módosítása-1) részben leírtak szerint tudod megváltoztatni.

:::tip

Mielőtt számlajavítást kérsz, győződj meg róla, hogy a fiókodban szereplő számlázási adatok helyesek. Ezzel nagyságrendekkel gyorsabb lesz a feldolgozás. Amennyiben a fiókodban szereplő adatoktól eltérő számlázási adatokat szeretnél módosítani, akkor mindenképpen küldd el nekünk a számlázási adatokat, hogy gyorsabban tudjuk feldolgozni a kérelmedet.