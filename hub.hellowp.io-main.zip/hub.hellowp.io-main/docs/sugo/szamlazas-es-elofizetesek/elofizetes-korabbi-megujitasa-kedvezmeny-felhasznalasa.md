---
sidebar_position: 8
---

# Előfizetés korábbi megújítása + kedvezmény felhasználása

Az összes HelloWP-s előfizetést bármikor megújíthatod, és ezzel a kedvezményedet is felhasználhatod.

### Előfizetés korábbi megújítása

1. Lépj be a HelloWP oldalon: https://hellowp.io/hu/helloconsole/ és Kattints a nevedre a jobb felső sarokban.
2. Kattints a **Előfizetések** menüpontra.
3. Válaszd ki, hogy melyik előfizetést szeretnéd megújítani, majd **Megtekintés gomb**
4. Kattints a **Megújítás most** gombra és vidd végig a megújítás folyamatát.

### Kedvezmények felhasználása

Amennyiben kuponkódot szeretnél felhasználni, akkor az **Előfizetés korábbi megújítás** folyamatának végén kattints a **Kuponkód felhasználása** gombra és add meg a kódot.