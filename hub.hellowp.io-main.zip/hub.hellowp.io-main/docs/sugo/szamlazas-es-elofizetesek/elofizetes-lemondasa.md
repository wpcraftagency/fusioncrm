---
sidebar_position: 4
---

# Előfizetés lemondása


A lemondás egyszerű: Belépés után kattints a **nevedre** (jobb fent) vagy **Fiókom** (lent középen) menüpont és **Előfizetések menüpont**. Válaszd ki, hogy melyik előfizetést szeretnéd lemondani, majd **Megtekintés gomb** és itt a **Lemondás gomb**. Amennyiben a lemondás sikeres, akkor a megrendelés állapota **Lemondva** lesz. 

Az aktív előfizetéseidet itt találod: https://hellowp.io/hu/helloconsole/subscriptions/